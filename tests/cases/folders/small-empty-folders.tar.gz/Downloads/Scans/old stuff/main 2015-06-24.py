def value():
    return 632932592


print(value())
