def value():
    return 52871256


print(value())
